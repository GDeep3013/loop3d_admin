import React from 'react'

export default function Pagination() {
  return (
    <div>Pagination</div>
  )
}
