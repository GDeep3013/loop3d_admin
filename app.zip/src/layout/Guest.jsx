export default function Guest({ children }) {
  return <>{children}</>;
}
